-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2024 at 07:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsf_bakery`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$AIy0X1Ep6alaHDTofiChGeqq7k/d1Kc8vKQf1JZo0mKrzkkj6M626');

-- --------------------------------------------------------

--
-- Table structure for table `bom_produk`
--

CREATE TABLE `bom_produk` (
  `kode_bom` varchar(100) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `kebutuhan` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bom_produk`
--

INSERT INTO `bom_produk` (`kode_bom`, `kode_bk`, `kode_produk`, `nama_produk`, `kebutuhan`) VALUES
('B0001', 'M0002', 'P0001', 'Roti Manis', '2'),
('B0001', 'M0001', 'P0002', 'Donat SF Bakery', '4'),
('B0001', 'M0004', 'P0003', 'Roti Gulung Sosis', '3'),
('B0002', 'M0001', 'P0004', 'Roti Kosong panjang', '4'),
('B0002', 'M0004', 'P0005', 'Roti Kosong biasa', '3'),
('B0002', 'M0003', 'P0006', 'Roti Rasa coklat', '2'),
('B0003', 'M0002', 'P0007', 'Roti Rasa srikaya', '2'),
('B0003', 'M0003', 'P0008', 'Roti Rasa kelapa', '5'),
('B0003', 'M0005', 'P0009', 'Roti Rasa mentega mises', '5');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `kode_customer` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`kode_customer`, `nama`, `email`, `username`, `password`, `telp`) VALUES
('C0001', 'Susanti', 'santikaramona23@gmail.com', 'santi', 'santi', '0856748564'),
('C0002', 'Jhon verizal', 'verijhon654@gmail.com', 'peri', 'peri', '087804616097'),
('C0003', 'salsabila khairunnisa', 'salsabilakn06@gmail.com', 'ica', 'ica', '081267053020'),
('C0004', 'nadiautami463@gmail.com', 'nadiautami463@gmail.com', 'nadia', '$2y$10$k8VJQ3GgUCPoaOyjdzHnPeQLRZhQmQ0TlxvmRPcZC5bjTMhTeKs.y', '081267053020');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `kode_bk` varchar(100) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `satuan` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`kode_bk`, `nama`, `qty`, `satuan`, `harga`, `tanggal`) VALUES
('M0001', 'Tepung', '100', 'Kg', 15000, '2024-07-01'),
('M0002', 'Pengembang', '100', 'Kg', 5000, '2024-07-01'),
('M0003', 'Cream', '17', 'Kg', 3000, '2020-07-26'),
('M0004', 'Keju', '82', 'Kg', 4000, '2020-07-26'),
('M0005', 'Coklat', '100', 'Kg', 45000, '2024-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `kode_customer` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `provinsi` varchar(255) NOT NULL,
  `kota` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `kode_pos` varchar(10) NOT NULL,
  `total_harga` decimal(15,2) NOT NULL,
  `tanggal` datetime NOT NULL,
  `status` enum('pending','paid','completed','cancelled') DEFAULT 'pending',
  `bukti_pembayaran` varchar(255) DEFAULT NULL,
  `payment_method` enum('transfer','cash') DEFAULT 'transfer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `kode_customer`, `nama`, `kode_produk`, `nama_produk`, `qty`, `harga`, `provinsi`, `kota`, `alamat`, `kode_pos`, `total_harga`, `tanggal`, `status`, `bukti_pembayaran`, `payment_method`) VALUES
(7, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'enj', 'sds', 'dx', '434', 2000.00, '2024-08-01 03:06:41', 'cancelled', NULL, 'cash'),
(8, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'enj', 'sds', 'dx', '434', 5000.00, '2024-08-01 06:08:32', 'cancelled', NULL, 'cash'),
(9, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'enj', 'sds', 'dx', '434', 5000.00, '2024-08-01 06:10:34', 'cancelled', NULL, 'cash'),
(10, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Padang', 'Jln. Ganting 1', '1255', 2000.00, '2024-08-01 08:14:20', 'cancelled', NULL, 'cash'),
(11, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'kai', 'kai', 'kai', '12345', 2000.00, '2024-08-01 10:52:12', 'pending', '66aaf3c2c67df.jpg', 'cash'),
(12, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Padang', 'aur duri ', '2347', 45000.00, '2024-08-01 13:43:48', 'paid', 'FLOWCHART  Mengelola laporan penjualan.jpeg', 'cash'),
(13, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, '', '', '', '', 5000.00, '2024-08-04 17:12:47', 'pending', NULL, 'cash'),
(14, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Bukitinggi', 'Jln. Ganting 1', '1255', 40000.00, '2024-08-04 17:16:53', 'pending', NULL, 'cash'),
(15, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Bukitinggi', 'Jln. Ganting 1', '1255', 10000.00, '2024-08-04 17:18:25', 'pending', NULL, 'cash'),
(16, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Bukitinggi', 'Jln. Ganting 1', '1255', 25000.00, '2024-08-04 17:21:03', 'pending', NULL, 'cash'),
(17, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Bukitinggi', 'Jln. Ganting 1', '1255', 5000.00, '2024-08-04 17:25:57', 'cancelled', '1', 'cash'),
(18, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Bukitinggi', 'Jln. Ganting 1', '1255', 20000.00, '2024-08-05 07:54:53', 'pending', 'CLASS DIAGRAM.jpeg', 'cash'),
(19, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Bukitinggi', 'Jln. Ganting 1', '1255', 10000.00, '2024-08-05 12:37:41', 'pending', NULL, 'cash'),
(20, 'C0004', 'nadiautami463@gmail.com', '', '', 0, 0, 'Sumatera Barat', 'Bukitinggi', 'Jln. Ganting 1', '1255', 20000.00, '2024-08-05 12:38:54', 'pending', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_detail`
--

CREATE TABLE `invoice_detail` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `kode_produk` varchar(255) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `harga` decimal(15,2) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoice_detail`
--

INSERT INTO `invoice_detail` (`id`, `invoice_id`, `kode_produk`, `nama_produk`, `harga`, `qty`) VALUES
(3, 7, 'P0002', 'Donat SF Bakery', 2000.00, 1),
(4, 8, 'P0003', 'Roti Gulung Sosis', 5000.00, 1),
(5, 9, 'P0003', 'Roti Gulung Sosis', 5000.00, 1),
(6, 10, 'P0002', 'Donat SF Bakery', 2000.00, 1),
(7, 11, 'P0002', 'Donat SF Bakery', 2000.00, 1),
(8, 12, 'P0002', 'Donat SF Bakery', 2000.00, 10),
(9, 12, 'P0003', 'Roti Gulung Sosis', 5000.00, 5),
(10, 13, 'P0003', 'Roti Gulung Sosis', 5000.00, 1),
(11, 14, 'P0002', 'Donat SF Bakery', 2000.00, 20),
(12, 15, 'P0001', 'Roti Manis', 10000.00, 1),
(13, 16, 'P0003', 'Roti Gulung Sosis', 5000.00, 5),
(14, 17, 'P0003', 'Roti Gulung Sosis', 5000.00, 1),
(15, 18, 'P0001', 'Roti Manis', 10000.00, 2),
(16, 19, 'P0001', 'Roti Manis', 10000.00, 1),
(17, 20, 'P0002', 'Donat SF Bakery', 2000.00, 10);

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `kode_customer` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id_keranjang`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`) VALUES
(27, 'C0005', 'P0001', 'Roti Manis', 1, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `kode_customer` varchar(50) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

CREATE TABLE `owner` (
  `idowner` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`idowner`, `username`, `password`) VALUES
(1, 'owner', '$2y$10$AIy0X1Ep6alaHDTofiChGeqq7k/d1Kc8vKQf1JZo0mKrzkkj6M626');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `kode_produk` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `deskripsi` text NOT NULL,
  `tgl_buat` date NOT NULL,
  `expired` date NOT NULL,
  `stok` int(100) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`kode_produk`, `nama`, `image`, `deskripsi`, `tgl_buat`, `expired`, `stok`, `harga`) VALUES
('P0001', 'Roti Manis', '66987abf804ff.jpg', '				Roti manis kami adalah pilihan sempurna untuk menemani saat-saat santai Anda bersama secangkir teh atau kopi. Dibuat dengan bahan-bahan pilihan berkualitas tinggi, setiap roti manis dipanggang dengan penuh cinta untuk menghasilkan tekstur yang lembut dan aroma yang menggugah selera.\r\n			', '2024-07-15', '2024-07-29', 100, 10000),
('P0002', 'Donat SF Bakery', '66987aceba2d4.jpg', '				Donat warna-warni kami adalah pilihan sempurna untuk menambah keceriaan pada hari Anda. Dibuat dengan bahan-bahan pilihan berkualitas tinggi, setiap donat dihiasi dengan lapisan glaze berwarna-warni yang menggoda selera. \r\n			', '2024-07-17', '2024-07-19', 100, 2000),
('P0003', 'Roti Gulung Sosis', '66987ae196b4b.jpg', '				Roti gulung sosis kami adalah perpaduan sempurna antara roti lembut yang dipanggang dengan keemasan dan sosis yang gurih. Dibuat dengan bahan-bahan berkualitas tinggi, setiap roti gulung sosis diolah dengan penuh perhatian untuk memberikan cita rasa yang tak tertandingi.\r\n				', '2024-07-16', '2024-07-20', 100, 5000),
('P0004', 'Roti Panjang Kosong', '66aaf61e471c0.jpg', 'Nikmati kesederhanaan yang memikat dari Roti Panjang Kosong kami. Dengan tekstur yang lembut dan rasa yang gurih, roti ini cocok dinikmati kapan saja. Dibuat dari bahan-bahan pilihan yang berkualitas, Roti Panjang Kosong kami menawarkan kenikmatan klasik yang sempurna untuk sarapan, camilan, atau teman makan siang Anda.\r\n			', '2024-08-01', '2024-08-17', 100, 15000),
('P0005', 'Roti Kosong', '66aaf7ce30a03.jpg', 'Nikmati keleluasaan rasa dengan Roti Kosong kami yang lembut dan ringan. Dibuat dengan bahan berkualitas tinggi dan tanpa tambahan bahan-bahan yang tidak perlu, roti ini adalah pilihan sempurna untuk melengkapi berbagai hidangan atau sebagai cemilan yang sederhana namun memuaskan. Ideal untuk sarapan, camilan sore, atau sebagai pendamping untuk hidangan favorit Anda. Roti Kosong kami dipanggang dengan penuh perhatian untuk memastikan tekstur yang empuk dan rasa yang bersih, memberikan kesegaran dan kenikmatan di setiap gigitan.', '2024-08-01', '2024-08-17', 100, 7000),
('P0006', 'Roti Coklat Kacang', '66aaf900a16b2.jpg', 'Nikmati kelezatan yang memanjakan lidah dengan Roti Coklat Kacang kami. Terbuat dari adonan roti yang lembut dan empuk, dipadukan dengan coklat berkualitas tinggi dan taburan kacang panggang yang renyah. Setiap gigitan memberikan kombinasi sempurna antara rasa manis coklat yang kaya dan gurihnya kacang, menjadikannya pilihan ideal untuk sarapan atau camilan sore. Roti ini dipanggang dengan penuh cinta, memastikan kesegaran dan cita rasa yang optimal setiap saat. Cobalah dan rasakan kenikmatannya!	', '2024-08-01', '2024-08-10', 100, 2000),
('P0007', 'Roti Srikaya', '66ab0028a682d.jpg', 'Roti Srikaya adalah perpaduan sempurna antara tekstur lembut roti dan kelezatan selai srikaya yang kaya rasa. Kami menggunakan adonan roti yang dipanggang dengan sempurna, menghasilkan kerak yang renyah dan bagian dalam yang empuk. Selai srikaya kami terbuat dari kelapa segar dan gula merah, memberikan rasa manis dan gurih yang khas, yang meresap hingga ke dalam setiap lapisan roti.', '2024-08-01', '2024-08-10', 100, 2000),
('P0008', 'Roti Kelapa', '66ab0092badbe.jpg', 'Roti Kelapa adalah pengalaman kuliner yang menggugah selera, menggabungkan adonan roti yang empuk dengan aroma dan rasa kelapa yang khas. Setiap roti dipanggang hingga mencapai kekuatan optimal, menghasilkan kerak yang renyah di luar dan bagian dalam yang lembut dan beraroma. Kami menggunakan kelapa segar dan bahan-bahan berkualitas tinggi untuk menciptakan rasa yang autentik dan memikat.', '2024-08-01', '2024-08-10', 100, 2000),
('P0009', 'Roti Mentega Meses', '66ab01167f68c.jpg', 'Roti Mentega Meses adalah pilihan sempurna bagi Anda yang mencari camilan manis yang memanjakan. Kami menggunakan adonan roti berkualitas tinggi yang dipanggang hingga mencapai kelembutan optimal, dipadu dengan olesan mentega yang kaya dan meses cokelat yang melimpah. Kombinasi ini menciptakan perpaduan rasa yang menggugah selera dan memanjakan setiap saat Anda menikmatinya.', '2024-08-01', '2024-08-10', 100, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `produksi`
--

CREATE TABLE `produksi` (
  `id_order` int(11) NOT NULL,
  `invoice` varchar(200) NOT NULL,
  `kode_customer` varchar(200) NOT NULL,
  `kode_produk` varchar(200) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Menunggu Pembayaran',
  `tanggal` date NOT NULL,
  `provinsi` varchar(200) NOT NULL,
  `kota` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kode_pos` varchar(200) NOT NULL,
  `terima` varchar(200) NOT NULL,
  `tolak` varchar(200) NOT NULL,
  `cek` int(11) NOT NULL,
  `bukti_pembayaran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produksi`
--

INSERT INTO `produksi` (`id_order`, `invoice`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`, `status`, `tanggal`, `provinsi`, `kota`, `alamat`, `kode_pos`, `terima`, `tolak`, `cek`, `bukti_pembayaran`) VALUES
(8, 'INV0001', 'C0002', 'P0003', 'Roti Gulung sosis', 10, 5000, 'Terima', '2024-07-16', 'Sumatera Barat', 'kota padang', 'jl. kampung marapak 1', '25117', '1', '0', 1, ''),
(9, 'INV0002', 'C0003', 'P0001', 'Roti manis', 3, 10000, 'Terima', '2024-07-10', 'Sumatera barat', 'kota padang', 'jl. andalas ', '25126', '1', '0', 1, ''),
(10, 'INV0003', 'C0001', 'P0003', 'Donat SF Bakery', 20, 2000, 'Terima', '2020-07-27', 'sumatera barat', 'padang', 'Jl.ganting 1', '25122', '1', '0', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `report_inventory`
--

CREATE TABLE `report_inventory` (
  `id_report_inv` int(11) NOT NULL,
  `kode_bk` varchar(100) NOT NULL,
  `nama_bahanbaku` varchar(100) NOT NULL,
  `jml_stok_bk` int(11) NOT NULL,
  `tanggal` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_omset`
--

CREATE TABLE `report_omset` (
  `id_report_omset` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_omset` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report _penjualan`
--

CREATE TABLE `report _penjualan` (
  `id_report_sell` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `jumlah_terjual` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_produksi`
--

CREATE TABLE `report_produksi` (
  `id_report_prd` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_profit`
--

CREATE TABLE `report_profit` (
  `id_report_profit` int(11) NOT NULL,
  `kode_bom` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `jumlah` varchar(11) NOT NULL,
  `total_profit` varchar(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shipping_rates`
--

CREATE TABLE `shipping_rates` (
  `id` int(11) NOT NULL,
  `provinsi` varchar(100) NOT NULL,
  `kota` varchar(100) NOT NULL,
  `within_city` tinyint(1) NOT NULL,
  `ongkir` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipping_rates`
--

INSERT INTO `shipping_rates` (`id`, `provinsi`, `kota`, `within_city`, `ongkir`) VALUES
(1, 'Sumatera Barat', 'Padang', 1, 15000.00),
(2, 'Sumatera Barat', 'Padang', 0, 25000.00),
(3, 'Jawa Barat', 'Bandung', 1, 10000.00),
(4, 'Jawa Barat', 'Bandung', 0, 20000.00),
(5, 'Jawa Timur', 'Surabaya', 1, 12000.00),
(6, 'Jawa Timur', 'Surabaya', 0, 22000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`kode_bk`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_detail`
--
ALTER TABLE `invoice_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `owner`
--
ALTER TABLE `owner`
  ADD PRIMARY KEY (`idowner`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indexes for table `produksi`
--
ALTER TABLE `produksi`
  ADD PRIMARY KEY (`id_order`);

--
-- Indexes for table `report_inventory`
--
ALTER TABLE `report_inventory`
  ADD PRIMARY KEY (`id_report_inv`);

--
-- Indexes for table `report_omset`
--
ALTER TABLE `report_omset`
  ADD PRIMARY KEY (`id_report_omset`);

--
-- Indexes for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  ADD PRIMARY KEY (`id_report_sell`);

--
-- Indexes for table `report_produksi`
--
ALTER TABLE `report_produksi`
  ADD PRIMARY KEY (`id_report_prd`);

--
-- Indexes for table `report_profit`
--
ALTER TABLE `report_profit`
  ADD PRIMARY KEY (`id_report_profit`),
  ADD UNIQUE KEY `kode_bom` (`kode_bom`);

--
-- Indexes for table `shipping_rates`
--
ALTER TABLE `shipping_rates`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `invoice_detail`
--
ALTER TABLE `invoice_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `owner`
--
ALTER TABLE `owner`
  MODIFY `idowner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `produksi`
--
ALTER TABLE `produksi`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `report_inventory`
--
ALTER TABLE `report_inventory`
  MODIFY `id_report_inv` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_omset`
--
ALTER TABLE `report_omset`
  MODIFY `id_report_omset` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report _penjualan`
--
ALTER TABLE `report _penjualan`
  MODIFY `id_report_sell` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_produksi`
--
ALTER TABLE `report_produksi`
  MODIFY `id_report_prd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_profit`
--
ALTER TABLE `report_profit`
  MODIFY `id_report_profit` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shipping_rates`
--
ALTER TABLE `shipping_rates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_detail`
--
ALTER TABLE `invoice_detail`
  ADD CONSTRAINT `invoice_detail_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
