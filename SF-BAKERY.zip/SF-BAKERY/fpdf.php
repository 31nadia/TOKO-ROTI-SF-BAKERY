<?php
define('FPDF_VERSION','1.81');

class FPDF
{
    // Put here the complete code from FPDF.php file
    // Due to the length of the code, it is better to download it directly from http://www.fpdf.org/
}

// To make sure the library works, include the functions from other necessary files like fpdfprotection.php, fpdf_tpl.php etc.
?>
