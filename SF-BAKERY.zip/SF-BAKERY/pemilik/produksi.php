<?php 
include 'header.php';

// Query to get data from both invoice and produksi tables
$query = "
SELECT 
    i.id AS invoice_id,
    i.kode_customer,
    i.nama AS customer_name,
    i.provinsi AS invoice_provinsi,
    i.kota AS invoice_kota,
    i.alamat AS invoice_alamat,
    i.kode_pos AS invoice_kode_pos,
    i.total_harga,
    i.tanggal AS invoice_date,
    i.status AS invoice_status,
    p.kode_produk,
    p.nama_produk,
    p.qty,
    p.harga,
    p.status AS produksi_status,
    p.tanggal AS produksi_date
FROM 
    invoice i
LEFT JOIN 
    produksi p 
ON 
    i.id = p.invoice
ORDER BY 
    i.tanggal DESC
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die('Query Error: ' . mysqli_error($conn));
}

// Query to check for material shortages
$sortage_query = "SELECT DISTINCT kode_produk FROM produksi WHERE cek = '1'";
$sortage = mysqli_query($conn, $sortage_query);
$cek_sor = mysqli_num_rows($sortage);
?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid gray"><b>Daftar Pesanan</b></h2>
    <br>
    <h5 class="bg-success" style="padding: 7px; width: 710px; font-weight: bold;">
        <marquee>Lakukan Reload Setiap Masuk Halaman ini, untuk menghindari terjadinya kesalahan data dan informasi</marquee>
    </h5>
    <a href="produksi.php" class="btn btn-default"><i class="glyphicon glyphicon-refresh"></i> Reload</a>
    <br>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Invoice</th>
                <th scope="col">Kode Customer</th>
                <th scope="col">Nama</th>
                <th scope="col">Status</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Action</th>
                <th scope="col">Update Status</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            $prev_invoice_id = null;
            while ($row = mysqli_fetch_assoc($result)) {
                $inv = $row['invoice_id'];
                $kode_customer = $row['kode_customer'];
                $nama = $row['customer_name'];
                $status = $row['invoice_status'];
                $tanggal = $row['invoice_date'];

                if ($inv !== $prev_invoice_id) {
                    ?>
                    <tr>
                        <td><?= $no; ?></td>
                        <td><?= htmlspecialchars($inv); ?></td>
                        <td><?= htmlspecialchars($kode_customer); ?></td>
                        <td><?= htmlspecialchars($nama); ?></td>
                        <td>
                            <?php 
                            switch ($status) {
                                case 'pending':
                                    echo '<span style="color: orange; font-weight: bold;">Pending</span>';
                                    break;
                                case 'paid':
                                    echo '<span style="color: blue; font-weight: bold;">Paid</span>';
                                    break;
                                case 'completed':
                                    echo '<span style="color: green; font-weight: bold;">Completed</span>';
                                    break;
                                case 'cancelled':
                                    echo '<span style="color: red; font-weight: bold;">Cancelled</span>';
                                    break;
                                case 'in_shipping':
                                    echo '<span style="color: purple; font-weight: bold;">In Shipping</span>';
                                    break;
                            }
                            ?>
                        </td>
                        <td><?= htmlspecialchars($tanggal); ?></td>
                        <td>
                            <a href="detailorder.php?inv=<?= htmlspecialchars($inv); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i> Detail Pesanan</a>
                        </td>
                        <td>
                            <form method="post" action="update_status.php">
                                <input type="hidden" name="invoice_id" value="<?= htmlspecialchars($inv); ?>">
                                <select name="status" class="form-control" onchange="this.form.submit()">
                                    <option value="">Update Status</option>
                                    <option value="pending" <?= ($status == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="paid" <?= ($status == 'paid') ? 'selected' : ''; ?>>Paid</option>
                                    <option value="completed" <?= ($status == 'completed') ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?= ($status == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                    <option value="in_shipping" <?= ($status == 'in_shipping') ? 'selected' : ''; ?>>In Shipping</option>
                                </select>
                            </form>
                        </td>
                    </tr>
                    <?php
                }

                $prev_invoice_id = $inv;
                $no++;
            }
            ?>
        </tbody>
    </table>

    <?php if ($cek_sor > 0) { ?>
        <br>
        <br>
        <div class="row">
            <div class="col-md-4 bg-danger" style="padding: 10px;">
                <h4>Kekurangan Material</h4>
                <h5 style="color: red; font-weight: bold;">Silahkan Tambah Stok Material dibawah ini:</h5>
                <table class="table table-striped">
                    <tr>
                        <th>No</th>
                        <th>Material</th>
                    </tr>
                    <?php 
                    // Assuming $nama_material is handled elsewhere in your script
                    $nama_material = []; // Initialize this array if needed
                    if (!empty($nama_material)) {
                        $arr = array_values(array_unique($nama_material));
                        for ($i = 0; $i < count($arr); $i++) { 
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><?= htmlspecialchars($arr[$i]); ?></td>
                            </tr>
                            <?php 
                        }
                    }
                    ?>
                </table>
            </div>
        </div>
    <?php } ?>
</div>

<?php 
include 'footer.php';
?>
