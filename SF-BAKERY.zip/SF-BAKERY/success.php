<?php
include 'header.php';
include 'koneksi/koneksi.php';
$invoice_id = mysqli_real_escape_string($conn, $_GET['invoice_id']);
$invoice_query = mysqli_query($conn, "SELECT * FROM invoice WHERE id = '$invoice_id'");
$invoice = mysqli_fetch_assoc($invoice_query);
?>
<div class="container">
    <h2>Payment Success</h2>
    <p>Thank you for your payment. Your order has been successfully placed.</p>
    <h4>Invoice Details</h4>
    <table class="table table-striped">
        <tr>
            <th>Invoice ID</th>
            <td><?= $invoice['id']; ?></td>
        </tr>
        <tr>
            <th>Tanggal</th>
            <td><?= $invoice['tanggal']; ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?= $invoice['status']; ?></td>
        </tr>
        <tr>
            <th>Total Harga</th>
            <td>Rp.<?= number_format($invoice['total_harga']); ?></td>
        </tr>
    </table>
    <a href="index.php" class="btn btn-primary">Back to Home</a>
</div>
<?php include 'footer.php'; ?>
