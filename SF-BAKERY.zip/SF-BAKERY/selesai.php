<?php 
include 'header.php';
?>

<div class="container" style="padding-bottom: 300px;">
    <h2 class="bg-success text-center" style="padding: 10px;">Checkout Berhasil</h2>
    <h4 class="text-center" style="font-weight: bold;">Terimakasih Sudah Berbelanja di Rapi-Cake Bakery, Pesananmu sedang diproses. Silahkan tunggu barangmu di rumah ya.. :)</h4>
    <div class="text-center" style="margin-top: 20px;">
        <?php if(isset($_GET['order_id'])): ?>
            <a href="generate_receipt.php?order_id=<?= htmlspecialchars($_GET['order_id']); ?>" class="btn btn-primary">Unduh Struk</a>
        <?php else: ?>
            <p>Error: Order ID tidak ditemukan.</p>
        <?php endif; ?>
    </div>
</div>

<?php 
include 'footer.php';
?>
