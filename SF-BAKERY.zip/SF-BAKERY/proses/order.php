<?php
include '../header.php'; // Ensure the location of the file is correct
include '../koneksi/koneksi.php'; // Including the database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kd_cs = mysqli_real_escape_string($conn, $_POST['kode_cs']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $prov = mysqli_real_escape_string($conn, $_POST['prov']);
    $kota = mysqli_real_escape_string($conn, $_POST['kota']);
    $alamat = mysqli_real_escape_string($conn, $_POST['almt']);
    $kopos = mysqli_real_escape_string($conn, $_POST['kopos']);
    $metode_pembayaran = mysqli_real_escape_string($conn, $_POST['metode_pembayaran']);
    $tanggal = date('Y-m-d');

    // Generate unique invoice number
    $kode = mysqli_query($conn, "SELECT invoice FROM produksi ORDER BY invoice DESC");
    $data = mysqli_fetch_assoc($kode);
    $num = substr($data['invoice'], 3, 4);
    $add = (int) $num + 1;

    if (strlen($add) == 1) {
        $format = "INV000" . $add;
    } else if (strlen($add) == 2) {
        $format = "INV00" . $add;
    } else if (strlen($add) == 3) {
        $format = "INV0" . $add;
    } else {
        $format = "INV" . $add;
    }

    // Insert order into the orders table
    $query = "INSERT INTO orders (kode_customer, nama, provinsi, kota, alamat, kode_pos, metode_pembayaran) 
              VALUES ('$kd_cs', '$nama', '$prov', '$kota', '$alamat', '$kopos', '$metode_pembayaran')";

    if (mysqli_query($conn, $query)) {
        $order_id = mysqli_insert_id($conn);

        // Move items from cart to order_items and produksi
        $keranjang = mysqli_query($conn, "SELECT * FROM keranjang WHERE kode_customer = '$kd_cs'");
        while ($row = mysqli_fetch_assoc($keranjang)) {
            $kd_produk = $row['kode_produk'];
            $nama_produk = $row['nama_produk'];
            $qty = $row['qty'];
            $harga = $row['harga'];
            $status = "Pesanan Baru";

            $order_item_query = "INSERT INTO order_items (order_id, product_id, qty, harga) 
                                 VALUES ('$order_id', '$kd_produk', '$qty', '$harga')";
            mysqli_query($conn, $order_item_query);

            $produksi_query = "INSERT INTO produksi (invoice, kode_customer, kode_produk, nama_produk, qty, harga, status, tanggal, provinsi, kota, alamat, kode_pos) 
                               VALUES ('$format', '$kd_cs', '$kd_produk', '$nama_produk', '$qty', '$harga', '$status', '$tanggal', '$prov', '$kota', '$alamat', '$kopos')";
            mysqli_query($conn, $produksi_query);
        }

        // Clear cart
        mysqli_query($conn, "DELETE FROM keranjang WHERE kode_customer = '$kd_cs'");

        // Payment processing logic
        if ($metode_pembayaran == 'bank_transfer') {
            // Generate unique bank transfer details
            $bank_account = '1234567890';
            $bank_name = 'Bank ABC';
            $amount = array_sum(array_column(mysqli_fetch_all($keranjang, MYSQLI_ASSOC), 'harga'));

            // Save bank transfer details
            $payment_query = "INSERT INTO payments (order_id, metode_pembayaran, bank_account, bank_name, amount, status) 
                              VALUES ('$order_id', 'bank_transfer', '$bank_account', '$bank_name', '$amount', 'pending')";
            mysqli_query($conn, $payment_query);

            // Redirect to bank transfer instructions page
            header("Location: ../bank_transfer.php?order_id=$order_id");
            exit();
        } else {
            // Handle other payment methods (e.g., credit card, PayPal)
            // Redirect to a confirmation page or display success message
            echo "<script>alert('Pesanan berhasil dibuat. Terima kasih telah berbelanja!'); window.location='../confirmation.php?order_id=$order_id';</script>";
        }
    } else {
        echo "<script>alert('Terjadi kesalahan saat memproses pesanan.'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Metode tidak valid.'); window.history.back();</script>";
}

include '../footer.php';
?>
