<?php
include 'header.php';
include 'koneksi/koneksi.php';

// Query untuk mendapatkan semua invoice
$invoice_query = mysqli_query($conn, "SELECT * FROM invoice");

?>

<div class="container">
    <h2>Daftar Invoice</h2>

    <!-- Menampilkan notifikasi jika ada -->
    <?php if (isset($_GET['status'])) { ?>
        <div class="alert alert-<?php echo ($_GET['status'] === 'canceled') ? 'warning' : ($_GET['status'] === 'success' ? 'success' : 'danger'); ?>" role="alert">
            <?php
            if ($_GET['status'] === 'success') {
                echo 'Pembayaran berhasil dikirim.';
            } elseif ($_GET['status'] === 'canceled') {
                echo 'Pesanan berhasil dibatalkan.';
            } else {
                echo 'Terjadi kesalahan. Silakan coba lagi.';
            }
            ?>
        </div>
    <?php } ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Invoice ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Total Harga</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Cek apakah ada invoice yang diambil
            if (mysqli_num_rows($invoice_query) > 0) {
                while ($invoice = mysqli_fetch_assoc($invoice_query)) { 
                    // Debug output
                    echo '<!-- Debug: payment_method: ' . htmlspecialchars($invoice['payment_method']) . ' -->';
                    
                    // Deskripsi status berdasarkan nilai
                    $statusDescription = '';
                    switch ($invoice['status']) {
                        case 'pending':
                            $statusDescription = 'Menunggu Konfirmasi';
                            break;
                        case 'confirmed':
                            $statusDescription = 'Konfirmasi Diproses';
                            break;
                        case 'shipped':
                            $statusDescription = 'Pesanan Diantar';
                            break;
                        case 'completed':
                            $statusDescription = 'Selesai';
                            break;
                        case 'cancelled':
                            $statusDescription = 'Dibatalkan';
                            break;
                        default:
                            $statusDescription = 'Status Tidak Dikenal';
                    }
            ?>
                    <tr>
                        <td><?= htmlspecialchars($invoice['id']); ?></td>
                        <td><?= htmlspecialchars($invoice['tanggal']); ?></td>
                        <td><?= htmlspecialchars($invoice['nama']); ?></td>
                        <td>Rp.<?= number_format($invoice['total_harga']); ?></td>
                        <td><?= htmlspecialchars($statusDescription); ?></td>
                        <td>
                            <a href="invoice_detail.php?invoice_id=<?= $invoice['id']; ?>" class="btn btn-info">Detail</a>
                            <a href="upload_payment.php?invoice_id=<?= $invoice['id']; ?>" class="btn btn-success">Upload Payment</a>
                            <a href="print_invoice.php?invoice_id=<?= $invoice['id']; ?>" class="btn btn-primary" target="_blank">Print Struk</a>
                            <!-- Tambahkan tombol pembatalan -->
                            <a href="cancel_order.php?invoice_id=<?= $invoice['id']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin membatalkan pesanan ini?')">Cancel</a>
                        </td>
                    </tr>
            <?php 
                } 
            } else {
                echo '<tr><td colspan="7">Tidak ada invoice yang ditemukan.</td></tr>';
            }
            ?>
        </tbody>
    </table>
</div>

<?php include 'footer.php'; ?>
