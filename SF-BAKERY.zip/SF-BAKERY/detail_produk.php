<?php 
include 'header.php';

// Mengambil kode produk dari parameter URL dan membersihkannya dari karakter yang tidak aman
$kode = mysqli_real_escape_string($conn, $_GET['produk']);

// Query untuk mendapatkan detail produk dari tabel produk
$result = mysqli_query($conn, "SELECT * FROM produk WHERE kode_produk = '$kode'");
if (!$result) {
    die('Query Error: ' . mysqli_error($conn));
}
$row = mysqli_fetch_assoc($result);
?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid #ff8680"><b>Detail Produk</b></h2>

    <div class="row">
        <div class="col-md-4">
            <div class="thumbnail">
                <img src="image/produk/<?= htmlspecialchars($row['image']); ?>" width="400" alt="<?= htmlspecialchars($row['nama']); ?>">
            </div>
        </div>

        <div class="col-md-8">
            <form action="proses/add.php" method="GET">
                <input type="hidden" name="kd_cs" value="<?= isset($kode_cs) ? htmlspecialchars($kode_cs) : ''; ?>">
                <input type="hidden" name="produk" value="<?= htmlspecialchars($kode); ?>">
                <input type="hidden" name="hal" value="2">
                <table class="table table-striped">
                    <tbody>
                        <tr>
                            <td><b>Nama</b></td>
                            <td><?= htmlspecialchars($row['nama']); ?></td>
                        </tr>
                        <tr>
                            <td><b>Harga</b></td>
                            <td>Rp. <?= number_format($row['harga']); ?></td>
                        </tr>
                        <tr>
                            <td><b>Deskripsi</b></td>
                            <td><?= htmlspecialchars($row['deskripsi']); ?></td>
                        </tr>
                        <tr>
                            <td><b>Stok</b></td>
                            <td><?= htmlspecialchars($row['stok']); ?></td>
                        </tr>
                        <tr>
                            <td><b>Tanggal Pembuatan</b></td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_buat'])); ?></td>
                        </tr>
                        <tr>
                            <td><b>Tanggal Kadaluarsa</b></td>
                            <td><?= date('d-m-Y', strtotime($row['expired'])); ?></td>
                        </tr>
                        <tr>
                            <td><b>Jumlah</b></td>
                            <td><input class="form-control" type="number" min="1" name="jml" value="1" style="width: 155px;"></td>
                        </tr>
                    </tbody>
                </table>
                <?php 
                if (isset($_SESSION['user'])) {
                    ?>
                    <button type="submit" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart"></i> Tambahkan ke Keranjang</button>
                    <?php 
                } else {
                    ?>
                    <a href="keranjang.php" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart"></i> Tambahkan ke Keranjang</a>
                    <?php 
                }
                ?>
                <a href="index.php" class="btn btn-warning"> Kembali Belanja</a>
            </form>
        </div>
    </div>	
    <br>
    <br>
</div>	

<?php 
include 'footer.php';
?>
