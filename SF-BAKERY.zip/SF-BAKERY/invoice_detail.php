<?php
include 'header.php';
include 'koneksi/koneksi.php';

// Fungsi untuk menghitung ongkos kirim berdasarkan provinsi, kota, dan status pengiriman dalam kota atau luar kota
function getOngkir($provinsi, $kota, $within_city, $conn) {
    // Mengonversi nilai boolean ke dalam integer untuk query
    $within_city = $within_city ? 1 : 0;

    // Query untuk mendapatkan ongkos kirim
    $sql = "SELECT ongkir FROM shipping_rates WHERE provinsi = ? AND kota = ? AND within_city = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param('ssi', $provinsi, $kota, $within_city);
        $stmt->execute();
        $stmt->bind_result($ongkir);
        $stmt->fetch();
        $stmt->close();

        // Mengembalikan ongkos kirim jika ditemukan, atau 0 jika tidak
        return $ongkir ? $ongkir : 0;
    } else {
        // Debug output jika terjadi kesalahan pada prepare statement
        echo "Error preparing statement: " . $conn->error;
        return 0;
    }
}

// Memeriksa apakah invoice_id ada dalam parameter URL
if (!isset($_GET['invoice_id']) || !is_numeric($_GET['invoice_id'])) {
    echo "Invalid invoice ID.";
    exit;
}

$invoice_id = mysqli_real_escape_string($conn, $_GET['invoice_id']);

// Query untuk mendapatkan data invoice berdasarkan invoice_id
$invoice_query = mysqli_query($conn, "SELECT * FROM invoice WHERE id = '$invoice_id'");
if (mysqli_num_rows($invoice_query) == 0) {
    echo "Invoice not found.";
    exit;
}
$invoice = mysqli_fetch_assoc($invoice_query);

// Query untuk mendapatkan detail pesanan berdasarkan invoice_id
$details_query = mysqli_query($conn, "SELECT * FROM invoice_detail WHERE invoice_id = '$invoice_id'");

// Memeriksa apakah invoice detail ada atau tidak
if (mysqli_num_rows($details_query) == 0) {
    echo "No order details found.";
    exit;
}

// Definisikan nilai within_city berdasarkan kondisi
$within_city = false; // Misalnya, ini bisa diatur sesuai dengan logika aplikasi Anda

// Menghitung ongkos kirim
$ongkir = getOngkir($invoice['provinsi'], $invoice['kota'], $within_city, $conn);

// Debug output untuk memastikan nilai ongkir
echo '<!-- Debug: ongkir: ' . htmlspecialchars($ongkir) . ' -->';

$total_harga = $invoice['total_harga'] + $ongkir;
?>

<div class="container">
    <h2>Invoice Detail</h2>
    <table class="table table-striped">
        <tr>
            <th>Invoice ID</th>
            <td><?= htmlspecialchars($invoice['id']); ?></td>
        </tr>
        <tr>
            <th>Tanggal</th>
            <td><?= htmlspecialchars($invoice['tanggal']); ?></td>
        </tr>
        <tr>
            <th>Nama</th>
            <td><?= htmlspecialchars($invoice['nama']); ?></td>
        </tr>
        <tr>
            <th>Alamat</th>
            <td><?= htmlspecialchars($invoice['alamat']) . ', ' . htmlspecialchars($invoice['kota']) . ', ' . htmlspecialchars($invoice['provinsi']) . ' ' . htmlspecialchars($invoice['kode_pos']); ?></td>
        </tr>
        <tr>
            <th>Total Harga</th>
            <td>Rp.<?= number_format($invoice['total_harga']); ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?= ucfirst(htmlspecialchars($invoice['status'])); ?></td>
        </tr>
        <tr>
            <th>Payment Method</th>
            <td><?= ucfirst(str_replace('_', ' ', htmlspecialchars($invoice['payment_method']))); ?></td>
        </tr>
        <tr>
            <th>Ongkos Kirim</th>
            <td>Rp.<?= number_format($ongkir); ?></td>
        </tr>
        <tr>
            <th>Total Pembayaran</th>
            <td>Rp.<?= number_format($total_harga); ?></td>
        </tr>
    </table>
    <h4>Detail Pesanan</h4>
    <table class="table table-striped">
        <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Qty</th>
            <th>Sub Total</th>
        </tr>
        <?php 
        $no = 1; 
        while($row = mysqli_fetch_assoc($details_query)) { ?>
        <tr>
            <td><?= $no; ?></td>
            <td><?= htmlspecialchars($row['nama_produk']); ?></td>
            <td>Rp.<?= number_format($row['harga']); ?></td>
            <td><?= htmlspecialchars($row['qty']); ?></td>
            <td>Rp.<?= number_format($row['harga'] * $row['qty']); ?></td>
        </tr>
        <?php 
        $no++; 
        } ?>
    </table>
    <a href="index.php" class="btn btn-primary">Back to Home</a>
</div>

<?php include 'footer.php'; ?>
