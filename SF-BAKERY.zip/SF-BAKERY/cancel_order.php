<?php
include 'header.php';
include 'koneksi/koneksi.php';

// Pastikan invoice_id diterima dari URL
if (isset($_GET['invoice_id'])) {
    $invoice_id = mysqli_real_escape_string($conn, $_GET['invoice_id']);

    // Query untuk membatalkan pesanan (mengubah status menjadi 'cancelled')
    $cancel_query = "UPDATE invoice SET status = 'cancelled' WHERE id = '$invoice_id'";

    if (mysqli_query($conn, $cancel_query)) {
        // Redirect dengan status sukses
        header("Location: invoice.php?status=canceled");
    } else {
        // Redirect dengan status gagal
        header("Location: invoice.php?status=error");
    }
} else {
    // Redirect jika invoice_id tidak ada
    header("Location: invoice.php?status=error");
}
?>
