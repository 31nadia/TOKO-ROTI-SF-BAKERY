<?php 
$conn = mysqli_connect("localhost", "root", "", "dbsf_bakery");
 ?>
