<?php
include 'header.php';
$order_id = $_GET['order_id'];
$query = "SELECT * FROM orders WHERE order_id = '$order_id'";
$order = mysqli_fetch_assoc(mysqli_query($conn, $query));

$query_items = "SELECT * FROM order_items WHERE order_id = '$order_id'";
$order_items = mysqli_query($conn, $query_items);
?>

<div class="container" style="padding-bottom: 200px">
    <h2 style="width: 100%; border-bottom: 4px solid #ff8680"><b>Konfirmasi Pesanan</b></h2>
    <div class="row">
        <div class="col-md-12">
            <h4>Detail Pesanan</h4>
            <table class="table table-striped">
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Qty</th>
                    <th>Sub Total</th>
                </tr>
                <?php 
                $no = 1;
                $hasil = 0;
                while($item = mysqli_fetch_assoc($order_items)){
                    ?>
                    <tr>
                        <td><?= $no; ?></td>
                        <td><?= $item['product_id']; ?></td>
                        <td>Rp.<?= number_format($item['harga']); ?></td>
                        <td><?= $item['qty']; ?></td>
                        <td>Rp.<?= number_format($item['harga'] * $item['qty']); ?></td>
                    </tr>
                    <?php 
                    $total = $item['harga'] * $item['qty'];
                    $hasil += $total;
                    $no++;
                }
                ?>
                <tr>
                    <td colspan="5" style="text-align: right; font-weight: bold;">Grand Total = Rp.<?= number_format($hasil); ?></td>
                </tr>
            </table>
            <a href="generate_receipt.php?order_id=<?= $order_id; ?>" class="btn btn-success">Unduh Struk</a>
        </div>
    </div>
</div>

<?php 
include 'footer.php';
?>
