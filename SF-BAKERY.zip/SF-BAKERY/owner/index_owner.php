<?php 
session_start();
if(isset($_SESSION['owner'])){
    header('location: halaman_utama.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SF Bakery Admin Login</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden; /* Prevent scrollbar due to background movement */
            font-family: 'Arial', sans-serif;
            color: #333; /* Default text color */
        }
        .login-container {
            position: relative;
            z-index: 1;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
            width: 350px;
            text-align: center;
        }
        .login-container h1 {
            margin-bottom: 1.5rem;
            color: #333; /* Heading text color */
        }
        .login-container input {
            width: calc(100% - 2rem);
            padding: 0.5rem;
            margin: 0.5rem 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        .login-container button {
            padding: 0.5rem 1rem;
            background-color: #007bff; /* Button background color */
            color: #fff; /* Button text color */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }
        .login-container button:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }
        .background-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 0;
            animation: animateBackground 20s linear infinite;
        }
        @keyframes animateBackground {
            0% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-50%);
            }
            100% {
                transform: translateY(0);
            }
        }
    </style>
    <script src="../js/jquery.js"></script>
    <script src="../js/bootstrap.min.js"></script>
</head>
<body>
    <!-- Background container for animated background -->
    <div class="background-container">
        <img src="../image/home/sf bakery.jpg" alt="Background Image" style="width: 100%; height: auto;">
    </div>

    <div class="login-container">
        <h1>Admin Login</h1>
        <h2>SF Bakery</h2>
        <form action="proses/login.php" method="POST">
            <div class="form-group">
                <label for="username" class="control-label">Username</label>
                <input type="text" class="form-control" id="username" name="user" placeholder="Username" autofocus autocomplete="off" required>
            </div>
            <div class="form-group">
                <label for="password" class="control-label">Password</label>
                <input type="password" class="form-control" id="password" name="pass" placeholder="Password" autocomplete="off" required>
            </div>
            <button type="submit" class="btn btn-warning">Login</button>
        </form>
    </div>

    <script>
        // JavaScript is optional for this animation
    </script>
</body>
</html>
