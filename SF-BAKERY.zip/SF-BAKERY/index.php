<?php 
include 'header.php';
?>
<!-- IMAGE -->
<div class="container-fluid" style="margin: 0;padding: 0;">
    <!-- Slider Produk -->
    <div id="product-carousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <?php 
            $result = mysqli_query($conn, "SELECT * FROM produk");
            $i = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                $active = ($i == 0) ? 'active' : '';
                echo '<li data-target="#product-carousel" data-slide-to="'.$i.'" class="'.$active.'"></li>';
                $i++;
            }
            ?>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <?php 
            $result = mysqli_query($conn, "SELECT * FROM produk");
            $i = 0;
            while ($row = mysqli_fetch_assoc($result)) {
                $active = ($i == 0) ? 'active' : '';
                echo '<div class="item '.$active.'">
                        <img src="image/produk/'.$row['image'].'" alt="'.$row['nama'].'" style="width: 100%; height: 500px; object-fit: cover;">
                        <div class="carousel-caption">
                            <h3>'.$row['nama'].'</h3>
                            <p>Rp.'.number_format($row['harga']).'</p>
                        </div>
                    </div>';
                $i++;
            }
            ?>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#product-carousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#product-carousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!-- End of Slider Produk -->
</div>
<br>
<br>

<!-- PRODUK TERBARU -->
<div class="container">
    <h4 class="text-center" style="font-family: arial; padding-top: 10px; padding-bottom: 10px; font-style: italic; line-height: 29px; border-top: 2px solid #ff8d87; border-bottom: 2px solid #ff8d87;"
    >SF BAKERY adalah sebuah usaha makanan / pabrik roti rumahan yang beralamat 
    di Jl. Simpang Maut Dalam, RT 001, RW 003, Kelurahan Bungo Pasang, Kecamatan Koto Tangah. 
    Kota Padang, Sumatera Barat. 25171. (Pabrik roti SF BAKERY berada dekat heler padi) 
    Kami menjual beraneka rasa roti yang biasa diletakkan di warung-warung dan kantin sekolah, 
    dimulai dari harga Rp. 2000,- sampai dengan harga Rp. 5000,- Variasi Roti: -Roti Manis/Roti Kasur -Roti Kosong/Sandwich -Roti Goreng rasa Coklat -Roti Donat Goreng 
    -Roti rasa Kelapa -Roti rasa Kelapa Kacang -Roti rasa Coklat -Roti rasa Coklat Kacang -Roti rasa Mentega Meses 
    -Roti rasa Srikaya/Pandan -Roti rasa Coklat Keju NB : Roti yang dibuat sesuai pesanan.</h4>

    <h2 style=" width: 100%; border-bottom: 4px solid #ff8680; margin-top: 80px;"><b>Produk Kami</b></h2>

    <div class="row">
        <?php 
        $result = mysqli_query($conn, "SELECT * FROM produk");
        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                    <img src="image/produk/<?= $row['image']; ?>" style="width: 100%; height: 200px; object-fit: cover;">
                    <div class="caption">
                        <h3><?= $row['nama'];  ?></h3>
                        <h4>Rp.<?= number_format($row['harga']); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <a href="detail_produk.php?produk=<?= $row['kode_produk']; ?>" class="btn btn-warning btn-block">Detail</a> 
                            </div>
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <div class="col-md-6">
                                    <a href="proses/add.php?produk=<?= $row['kode_produk']; ?>&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block" role="button"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                                </div>
                                <?php 
                            }
                            else{
                                ?>
                                <div class="col-md-6">
                                    <a href="keranjang.php" class="btn btn-success btn-block" role="button"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                                </div>
                                <?php 
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
        }
        ?>
    </div>
</div>
<br>
<br>
<br>
<br>
<?php 
include 'footer.php';
?> 

<script>
    $(document).ready(function(){
        // Activate Carousel
        $("#product-carousel").carousel({
            interval: 3000 // 3 seconds
        });
    });
</script>
