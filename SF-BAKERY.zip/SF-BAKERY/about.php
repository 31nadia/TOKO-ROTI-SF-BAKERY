<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #ff8680"><b>Tentang Kami</b></h2>
	<p class="text-justify">SF BAKERY adalah sebuah usaha makanan / pabrik roti rumahan yang beralamat 
    di Jl. Simpang Maut Dalam, RT 001, RW 003, Kelurahan Bungo Pasang, Kecamatan Koto Tangah. 
    Kota Padang, Sumatera Barat. 25171. (Pabrik roti SF BAKERY berada dekat heler padi) 
    Kami menjual beraneka rasa roti yang biasa diletakkan di warung-warung dan kantin sekolah, 
    dimulai dari harga Rp. 2000,- sampai dengan harga Rp. 5000,- Variasi Roti: -Roti Manis/Roti Kasur -Roti Kosong/Sandwich -Roti Goreng rasa Coklat -Roti Donat Goreng 
    -Roti rasa Kelapa -Roti rasa Kelapa Kacang -Roti rasa Coklat -Roti rasa Coklat Kacang -Roti rasa Mentega Meses 
    -Roti rasa Srikaya/Pandan -Roti rasa Coklat Keju NB : Roti yang dibuat sesuai pesanan.</p>




 <?php 
	include 'footer.php';
 ?>