<?php
include 'header.php';
?>

<div class="container">
    <h2>Informasi Rekening</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nomor Rekening</th>
                <th>Bank</th>
                <th>Atas Nama</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>9016-1010-1646</td>
                <td>Bank BTN</td>
                <td>Nadia Utami Putri</td>
            </tr>
            <!-- Tambahkan baris tambahan jika perlu -->
        </tbody>
    </table>
    
    <h2>Upload Bukti Pembayaran</h2>
    <form action="process_payment.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="invoice_id" value="<?= htmlspecialchars($_GET['invoice_id']); ?>">

        <div class="form-group">
            <label for="bukti_pembayaran">Bukti Pembayaran</label>
            <input type="file" class="form-control" id="bukti_pembayaran" name="bukti_pembayaran" accept="image/*" required>
        </div>
        <button type="submit" class="btn btn-success">Kirim Pembayaran</button>
        <a href="invoice.php" class="btn btn-primary">Back to Home</a>
    </form>
</div>

<?php include 'footer.php'; ?>
