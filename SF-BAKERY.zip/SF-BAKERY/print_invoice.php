<?php

include 'koneksi/koneksi.php';

// Mendapatkan ID invoice dari parameter URL
$invoice_id = $_GET['invoice_id'];

// Query untuk mendapatkan detail invoice
$invoice_query = mysqli_query($conn, "SELECT * FROM invoice WHERE id = '$invoice_id'");

// Mengecek apakah invoice ditemukan
if ($invoice = mysqli_fetch_assoc($invoice_query)) {
    // Deskripsi status berdasarkan nilai
    $statusDescription = '';
    switch ($invoice['status']) {
        case 'pending':
            $statusDescription = 'Menunggu Konfirmasi';
            break;
        case 'confirmed':
            $statusDescription = 'Konfirmasi Diproses';
            break;
        case 'shipped':
            $statusDescription = 'Pesan Diantar';
            break;
        case 'completed':
            $statusDescription = 'Selesai';
            break;
        default:
            $statusDescription = 'Status Tidak Dikenal';
    }

    // Menampilkan struk dalam format HTML
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Print Struk - Invoice <?= htmlspecialchars($invoice['id']); ?></title>
        <style>
            body {
                font-family: Arial, sans-serif;
            }
            .container {
                width: 80%;
                margin: 0 auto;
            }
            .invoice {
                border: 1px solid #000;
                padding: 20px;
                margin: 20px 0;
                width: 100%;
                max-width: 800px;
                background: #f9f9f9;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            .invoice h1 {
                text-align: center;
                font-size: 24px;
            }
            .invoice p {
                margin: 10px 0;
                font-size: 16px;
            }
            .invoice-footer {
                text-align: center;
                margin-top: 20px;
                font-size: 14px;
            }
            .invoice .header,
            .invoice .footer {
                border-bottom: 1px solid #000;
                border-top: 1px solid #000;
                padding: 10px 0;
            }
            .invoice .details {
                margin: 20px 0;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="invoice">
                <div class="header">
                    <h1>SF BAKERY</h1>
                </div>
                <div class="details">
                    <p><strong>Invoice ID:</strong> <?= htmlspecialchars($invoice['id']); ?></p>
                    <p><strong>Tanggal:</strong> <?= htmlspecialchars($invoice['tanggal']); ?></p>
                    <p><strong>Nama:</strong> <?= htmlspecialchars($invoice['nama']); ?></p>
                    <p><strong>Total Harga:</strong> Rp.<?= number_format($invoice['total_harga']); ?></p>
                    <p><strong>Status:</strong> <?= htmlspecialchars($statusDescription); ?></p>
                </div>
                <div class="footer">
                    <p>Terima kasih atas pembelian Anda!</p>
                </div>
            </div>
        </div>
        <script>
            window.onload = function() {
                window.print();
            }
        </script>
    </body>
    </html>
    <?php

} else {
    echo "Invoice tidak ditemukan.";
}


?>
