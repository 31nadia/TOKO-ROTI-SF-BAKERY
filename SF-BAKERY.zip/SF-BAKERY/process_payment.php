<?php
include 'koneksi/koneksi.php';

// Memeriksa apakah invoice_id ada dalam POST request
if (!isset($_POST['invoice_id']) || !is_numeric($_POST['invoice_id'])) {
    echo "Invalid invoice ID.";
    exit;
}

$invoice_id = mysqli_real_escape_string($conn, $_POST['invoice_id']);

// Memeriksa dan memproses upload bukti pembayaran
if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] == UPLOAD_ERR_OK) {
    $fileTmpPath = $_FILES['bukti_pembayaran']['tmp_name'];
    $fileName = $_FILES['bukti_pembayaran']['name'];
    $fileSize = $_FILES['bukti_pembayaran']['size'];
    $fileType = $_FILES['bukti_pembayaran']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));

    // Validasi ekstensi file
    $allowedExts = array('jpg', 'jpeg', 'png');
    if (in_array($fileExtension, $allowedExts)) {
        // Lokasi file upload
        $uploadFileDir = './uploads/';
        // Cek jika direktori uploads ada, jika tidak ada buat direktori
        if (!is_dir($uploadFileDir)) {
            if (!mkdir($uploadFileDir, 0755, true)) {
                echo "Gagal membuat direktori uploads.";
                exit;
            }
        }
        
        $dest_path = $uploadFileDir . $fileName;

        if (move_uploaded_file($fileTmpPath, $dest_path)) {
            // Menyimpan nama file bukti pembayaran dan mengubah status invoice
            $query = "UPDATE invoice 
                      SET bukti_pembayaran = '$fileName', status = 'pending' 
                      WHERE id = '$invoice_id'";

            if (mysqli_query($conn, $query)) {
                // Redirect dengan notifikasi
                header("Location: invoice.php?status=success");
                exit;
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "Gagal mengupload file.";
        }
    } else {
        echo "Jenis file tidak diperbolehkan.";
    }
} else {
    echo "Tidak ada file yang diupload atau terjadi kesalahan.";
}

mysqli_close($conn);
?>
