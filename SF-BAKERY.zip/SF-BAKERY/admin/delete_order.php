<?php
// Tentukan path yang benar untuk file koneksi.php
include '../koneksi/koneksi.php'; // Menyesuaikan path ke folder koneksi jika diperlukan

// Pastikan koneksi berhasil
if (!$conn) {
    die('Koneksi database gagal: ' . mysqli_connect_error());
}

// Pastikan invoice_id diterima dari URL
if (isset($_GET['invoice_id'])) {
    $invoice_id = mysqli_real_escape_string($conn, $_GET['invoice_id']);

    // Query untuk menghapus pesanan
    $delete_query = "DELETE FROM invoice WHERE id = '$invoice_id'";
    if (mysqli_query($conn, $delete_query)) {
        // Redirect dengan status sukses
        header("Location: produksi.php?status=deleted");
    } else {
        // Redirect dengan status gagal
        header("Location: produksi.php?status=error");
    }
} else {
    // Redirect jika invoice_id tidak ada
    header("Location: produksi.php?status=error");
}
?>
