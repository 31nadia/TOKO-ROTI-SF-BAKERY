<?php
include 'header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $invoice_id = $_POST['invoice_id'];
    $status = $_POST['status'];

    if (!empty($invoice_id) && !empty($status)) {
        $query = "UPDATE invoice SET status = '$status' WHERE id = '$invoice_id'";
        $result = mysqli_query($conn, $query);

        if (!$result) {
            die('Query Error: ' . mysqli_error($conn));
        }

        // Redirect back to the page
        header("Location: produksi.php");
        exit();
    } else {
        echo 'Invoice ID or Status is missing!';
    }
} else {
    echo 'Invalid request method!';
}
?>
