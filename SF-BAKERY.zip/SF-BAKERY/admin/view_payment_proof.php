<?php 
include 'header.php';

// Mendapatkan path file dari parameter URL
$file = isset($_GET['file']) ? urldecode($_GET['file']) : '';

// Validasi path file (simple validation)
if (empty($file) || !file_exists($file) || !is_image($file)) {
    echo '<div class="container"><h2>File tidak ditemukan atau format tidak didukung</h2></div>';
    include 'footer.php';
    exit;
}

// Fungsi untuk memeriksa apakah file adalah gambar
function is_image($file) {
    $image_extensions = ['jpg', 'jpeg', 'png', 'gif'];
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    return in_array($ext, $image_extensions);
}
?>

<div class="container">
    <h2>Detail Bukti Pembayaran</h2>
    <!-- Menampilkan gambar -->
    <img src="<?= htmlspecialchars($file); ?>" alt="Bukti Pembayaran" style="width: 100%; height: auto;" />
</div>

<?php 
include 'footer.php';
?>
