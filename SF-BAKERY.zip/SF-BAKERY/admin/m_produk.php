<?php 
include 'header.php';
?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid gray"><b>Master Produk</b></h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Kode Produk</th>
                <th scope="col">Nama Produk</th>
                <th scope="col">Image</th>
                <th scope="col">Harga</th>
                <th scope="col">Stok</th>
                <th scope="col">Tanggal Pembuatan</th>
                <th scope="col">Tanggal Kadaluarsa</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $result = mysqli_query($conn, "SELECT * FROM produk");
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?= $no; ?></td>
                    <td><?= htmlspecialchars($row['kode_produk']); ?></td>
                    <td><?= htmlspecialchars($row['nama']); ?></td>
                    <td><img src="../image/produk/<?= htmlspecialchars($row['image']); ?>" width="100" alt="<?= htmlspecialchars($row['nama']); ?>"></td>
                    <td>Rp. <?= number_format($row['harga']); ?></td>
                    <td><?= htmlspecialchars($row['stok']); ?></td>
                    <td><?= date('d-m-Y', strtotime($row['tgl_buat'])); ?></td>
                    <td><?= date('d-m-Y', strtotime($row['expired'])); ?></td>
                    <td>
                        <a href="edit_produk.php?kode=<?= htmlspecialchars($row['kode_produk']); ?>" class="btn btn-warning"><i class="glyphicon glyphicon-edit"></i> Edit</a>
                        <a href="proses/del_produk.php?kode=<?= htmlspecialchars($row['kode_produk']); ?>" class="btn btn-danger" onclick="return confirm('Yakin Ingin Menghapus Data?')"><i class="glyphicon glyphicon-trash"></i> Hapus</a>
                        <a href="bom.php?kode=<?= htmlspecialchars($row['kode_produk']); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i> Lihat BOM</a>
                    </td>
                </tr>
            <?php
                $no++; 
            }
            ?>
        </tbody>
    </table>
    <a href="tm_produk.php" class="btn btn-success"><i class="glyphicon glyphicon-plus-sign"></i> Tambah Produk</a>
</div>

<?php 
include 'footer.php';
?>
