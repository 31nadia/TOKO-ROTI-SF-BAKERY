<?php 
include 'header.php';

// Mendapatkan invoice ID dari parameter URL
$invoice_id = isset($_GET['inv']) ? urldecode($_GET['inv']) : '';

// Validasi parameter invoice ID
if (empty($invoice_id)) {
    echo '<div class="container"><h2>Invoice tidak ditemukan</h2></div>';
    include 'footer.php';
    exit;
}

// Query untuk mendapatkan data dari tabel invoice
$query = "SELECT * FROM invoice WHERE id = '$invoice_id'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die('Query Error: ' . mysqli_error($conn));
}

$invoice = mysqli_fetch_assoc($result);

if (!$invoice) {
    echo '<div class="container"><h2>Invoice tidak ditemukan</h2></div>';
    include 'footer.php';
    exit;
}

// Pastikan ada nilai untuk ongkir
$total_ongkir = !empty($invoice['ongkir']) ? (float)$invoice['ongkir'] : 0.0;

// Query untuk mengecek kekurangan material
$sortage_query = "SELECT * FROM produksi WHERE cek = '1' AND invoice = '$invoice_id'";
$sortage = mysqli_query($conn, $sortage_query);
$cek_sor = mysqli_num_rows($sortage);

// Mendapatkan data customer
$customer_query = "SELECT * FROM customer WHERE kode_customer = '".$invoice['kode_customer']."'";
$customer_result = mysqli_query($conn, $customer_query);

if (!$customer_result) {
    die('Query Error: ' . mysqli_error($conn));
}

$customer = mysqli_fetch_assoc($customer_result);

// Menentukan URL gambar
$image_url = !empty($invoice['bukti_pembayaran']) ? 'http://yourdomain.com/uploads/' . basename($invoice['bukti_pembayaran']) : '';
?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid gray"><b>Detail Pesanan #<?= htmlspecialchars($invoice['id']); ?></b></h2>
    <br>
    <a href="produksi.php" class="btn btn-default"><i class="glyphicon glyphicon-refresh"></i> Reload</a>
    
    <table class="table table-striped">
        <tr>
            <td><b>Invoice</b></td>
            <td><?= htmlspecialchars($invoice['id']); ?></td>
        </tr>
        <tr>
            <td><b>Kode Customer</b></td>
            <td><?= htmlspecialchars($invoice['kode_customer']); ?></td>
        </tr>
        <tr>
            <td><b>Nama</b></td>
            <td><?= htmlspecialchars($invoice['nama']); ?></td>
        </tr>
        <tr>
            <td><b>Alamat</b></td>
            <td><?= htmlspecialchars($invoice['alamat'] . ", " . $invoice['kota'] . " " . $invoice['provinsi'] . ", " . $invoice['kode_pos']); ?></td>
        </tr>
        <tr>
            <td><b>No Telp</b></td>
            <td><?= htmlspecialchars($customer['telp']); ?></td>
        </tr>
        <tr>
            <td><b>Status</b></td>
            <td>
                <?php 
                $status = $invoice['status'];
                switch ($status) {
                    case 'pending':
                        echo '<span style="color: orange; font-weight: bold;">Pending</span>';
                        break;
                    case 'paid':
                        echo '<span style="color: blue; font-weight: bold;">Paid</span>';
                        break;
                    case 'completed':
                        echo '<span style="color: green; font-weight: bold;">Completed</span>';
                        break;
                    case 'cancelled':
                        echo '<span style="color: red; font-weight: bold;">Cancelled</span>';
                        break;
                    case 'in_shipping':
                        echo '<span style="color: purple; font-weight: bold;">In Shipping</span>';
                        break;
                }
                ?>
            </td>
        </tr>
        <tr>
            <td><b>Tanggal</b></td>
            <td><?= htmlspecialchars($invoice['tanggal']); ?></td>
        </tr>
        <?php if (!empty($invoice['bukti_pembayaran'])): ?>
        <tr>
            <td><b>Bukti Pembayaran</b></td>
            <td>
                <!-- Menampilkan gambar bukti pembayaran -->
                <img src="<?= htmlspecialchars($image_url); ?>" alt="Bukti Pembayaran" style="max-width: 100%; height: auto;" />
            </td>
        </tr>
        <?php else: ?>
        <tr>
            <td><b>Bukti Pembayaran</b></td>
            <td><i>Belum ada bukti pembayaran</i></td>
        </tr>
        <?php endif; ?>
    </table>

    <!-- Menampilkan list order -->
    <h4>List Order</h4>
    <table class="table table-striped">
        <tr>
            <th>No</th>
            <th>Kode Produk</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Qty</th>
            <th>Subtotal</th>
        </tr>
        <?php 
        $order_query = "SELECT * FROM produksi WHERE invoice = '$invoice_id'";
        $order_result = mysqli_query($conn, $order_query);
        if (!$order_result) {
            die('Query Error: ' . mysqli_error($conn));
        }
        $no = 1;
        $grand_total = 0;
        while ($order = mysqli_fetch_assoc($order_result)) {
            $subtotal = $order['harga'] * $order['qty'];
            $grand_total += $subtotal;
        ?>
        <tr>
            <td><?= $no; ?></td>
            <td><?= htmlspecialchars($order['kode_produk']); ?></td>
            <td><?= htmlspecialchars($order['nama_produk']); ?></td>
            <td><?= number_format($order['harga'], 0, ".", "."); ?></td>
            <td><?= htmlspecialchars($order['qty']); ?></td>
            <td><?= number_format($subtotal, 0, ".", "."); ?></td>
        </tr>
        <?php 
            $no++;
        }
        ?>
        <tr>
            <td colspan="6" class="text-right"><b>Grand Total = <?= number_format($grand_total + $total_ongkir, 2, ".", "."); ?> (Harga + Ongkir)</b></td>
        </tr>
        <tr>
            <td colspan="6" class="text-right"><b>Total Ongkir = <?= number_format($total_ongkir, 2, ".", "."); ?></b></td>
        </tr>
    </table>
</div>

<?php 
if ($cek_sor > 0) { ?>
<script>
    alert("Terdapat material shortage");
</script>
<?php } ?>

<?php include 'footer.php'; ?>
