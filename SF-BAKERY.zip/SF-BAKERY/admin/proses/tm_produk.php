<?php 
include '../../koneksi/koneksi.php';

// Generate kode BOM
$kode_bom = mysqli_query($conn, "SELECT kode_bom FROM bom_produk ORDER BY kode_bom DESC");
$data_bom = mysqli_fetch_assoc($kode_bom);
if ($data_bom['kode_bom'] == null) {
    $format_bom = "B0001";
} else {
    $num = substr($data_bom['kode_bom'], 1, 4);
    $add = (int) $num + 1;
    $format_bom = str_pad($add, 4, "0", STR_PAD_LEFT);
    $format_bom = "B" . $format_bom;
}

$kode_produk = $_POST['kode'];
$nm_produk = $_POST['nama'];
$harga = $_POST['harga'];
$desk = $_POST['desk'];
$tgl_buat = isset($_POST['tgl_buat']) ? $_POST['tgl_buat'] : null;
$expired = isset($_POST['expired']) ? $_POST['expired'] : null;
$stok = isset($_POST['stok']) ? $_POST['stok'] : null;
$nama_gambar = $_FILES['files']['name'];
$size_gambar = $_FILES['files']['size'];
$tmp_file = $_FILES['files']['tmp_name'];
$eror = $_FILES['files']['error'];
$type = $_FILES['files']['type'];

// BOM
$kd_material = isset($_POST['material']) ? $_POST['material'] : [];
$keb = isset($_POST['keb']) ? $_POST['keb'] : [];

// Check if product code already exists
$check_product = mysqli_query($conn, "SELECT kode_produk FROM produk WHERE kode_produk='$kode_produk'");
if (mysqli_num_rows($check_product) > 0) {
    echo "
    <script>
    alert('KODE PRODUK SUDAH ADA');
    window.location = '../tm_produk.php';
    </script>
    ";
    die;
}

if ($eror === 4) {
    echo "
    <script>
    alert('TIDAK ADA GAMBAR YANG DIPILIH');
    window.location = '../tm_produk.php';
    </script>
    ";
    die;
}

$ekstensiGambar = array('jpg', 'jpeg', 'png');
$ekstensiGambarValid = explode(".", $nama_gambar);
$ekstensiGambarValid = strtolower(end($ekstensiGambarValid));

if (!in_array($ekstensiGambarValid, $ekstensiGambar)) {
    echo "
    <script>
    alert('EKSTENSI GAMBAR HARUS JPG, JPEG, PNG');
    window.location = '../tm_produk.php';
    </script>
    ";
    die;
}

if ($size_gambar > 1000000) {
    echo "
    <script>
    alert('UKURAN GAMBAR TERLALU BESAR');
    window.location = '../tm_produk.php';
    </script>
    ";
    die;
}

$namaGambarBaru = uniqid();
$namaGambarBaru .= ".";
$namaGambarBaru .= $ekstensiGambarValid;

if (move_uploaded_file($tmp_file, "../../image/produk/" . $namaGambarBaru)) {
    // Insert produk
    $result_produk = mysqli_query($conn, "INSERT INTO produk (kode_produk, nama, image, deskripsi, tgl_buat, expired, stok, harga) VALUES ('$kode_produk', '$nm_produk', '$namaGambarBaru', '$desk', '$tgl_buat', '$expired', '$stok', '$harga')");

    if (!$result_produk) {
        echo "
        <script>
        alert('GAGAL MENAMBAH PRODUK');
        window.location = '../tm_produk.php';
        </script>
        ";
        die;
    }

    // Insert BOM
    $filter = array_filter($kd_material);
    $jml = count($filter) - 1;
    $no = 0;
    while ($no <= $jml) {
        $result_bom = mysqli_query($conn, "INSERT INTO bom_produk (kode_bom, kd_material, kode_produk, nama_produk, keb) VALUES ('$format_bom', '$kd_material[$no]', '$kode_produk', '$nm_produk', '$keb[$no]')");
        if (!$result_bom) {
            echo "
            <script>
            alert('GAGAL MENAMBAH DATA BOM');
            window.location = '../tm_produk.php';
            </script>
            ";
            die;
        }
        $no++;
    }

    echo "
    <script>
    alert('PRODUK BERHASIL DITAMBAHKAN');
    window.location = '../m_produk.php';
    </script>
    ";
}
?>
