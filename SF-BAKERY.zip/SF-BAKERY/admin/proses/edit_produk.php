<?php 
include '../../koneksi/koneksi.php';

$kode = $_GET['kode'];
$result = mysqli_query($conn, "SELECT * FROM produk WHERE kode_produk = '$kode'");
$row = mysqli_fetch_assoc($result);
?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid gray"><b>Edit Produk</b></h2>
    <form action="update_produk.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="kode" value="<?= htmlspecialchars($row['kode_produk']); ?>">
        <div class="form-group">
            <label for="nama">Nama Produk:</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= htmlspecialchars($row['nama']); ?>" required>
        </div>
        <div class="form-group">
            <label for="harga">Harga:</label>
            <input type="number" class="form-control" id="harga" name="harga" value="<?= htmlspecialchars($row['harga']); ?>" required>
        </div>
        <div class="form-group">
            <label for="stok">Stok:</label>
            <input type="number" class="form-control" id="stok" name="stok" value="<?= htmlspecialchars($row['stok']); ?>" required>
        </div>
        <div class="form-group">
            <label for="tgl_buat">Tanggal Pembuatan:</label>
            <input type="date" class="form-control" id="tgl_buat" name="tgl_buat" value="<?= htmlspecialchars($row['tgl_buat']); ?>" required>
        </div>
        <div class="form-group">
            <label for="expired">Tanggal Kadaluarsa:</label>
            <input type="date" class="form-control" id="expired" name="expired" value="<?= htmlspecialchars($row['expired']); ?>" required>
        </div>
        <div class="form-group">
            <label for="deskripsi">Deskripsi:</label>
            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required><?= htmlspecialchars($row['deskripsi']); ?></textarea>
        </div>
        <div class="form-group">
            <label for="image">Image:</label>
            <input type="file" class="form-control" id="image" name="files">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>

<?php 
include '../../footer.php';
?>
