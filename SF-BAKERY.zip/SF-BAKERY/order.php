<?php
include 'koneksi/koneksi.php'; // Pastikan ini termasuk file koneksi ke database
$kd = mysqli_real_escape_string($conn, $_POST['kode_cs']);
$nama = mysqli_real_escape_string($conn, $_POST['nama']);
$prov = mysqli_real_escape_string($conn, $_POST['prov']);
$kota = mysqli_real_escape_string($conn, $_POST['kota']);
$almt = mysqli_real_escape_string($conn, $_POST['almt']);
$kopos = mysqli_real_escape_string($conn, $_POST['kopos']);
$total_harga = 0;

// Hitung total harga
$result = mysqli_query($conn, "SELECT * FROM keranjang WHERE kode_customer = '$kd'");
while($row = mysqli_fetch_assoc($result)){
    $total_harga += $row['harga'] * $row['qty'];
}

// Insert data ke tabel invoice
$query = "INSERT INTO invoice (kode_customer, nama, provinsi, kota, alamat, kode_pos, total_harga, tanggal) VALUES ('$kd', '$nama', '$prov', '$kota', '$almt', '$kopos', '$total_harga', NOW())";
if(mysqli_query($conn, $query)){
    $invoice_id = mysqli_insert_id($conn);
    // Insert detail pesanan ke tabel invoice_detail
    $result = mysqli_query($conn, "SELECT * FROM keranjang WHERE kode_customer = '$kd'");
    while($row = mysqli_fetch_assoc($result)){
        $query_detail = "INSERT INTO invoice_detail (invoice_id, kode_produk, nama_produk, harga, qty) VALUES ('$invoice_id', '".$row['kode_produk']."', '".$row['nama_produk']."', '".$row['harga']."', '".$row['qty']."')";
        mysqli_query($conn, $query_detail);
    }
    // Kosongkan keranjang belanja
    mysqli_query($conn, "DELETE FROM keranjang WHERE kode_customer = '$kd'");
    header('Location:invoice.php?invoice_id=' . $invoice_id);
} else {
    echo "Error: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
