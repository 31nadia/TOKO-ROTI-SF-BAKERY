<?php
require('fpdf.php');
include 'koneksi/koneksi.php'; // Pastikan ini menghubungkan ke database Anda


if (!isset($_GET['order_id'])) {
    die("Error: Order ID tidak ditemukan.");
}

$order_id = mysqli_real_escape_string($conn, $_GET['order_id']);

// Query untuk mengambil detail pesanan
$query = "SELECT * FROM produksi WHERE id_order = '$order_id'";
$result_order = mysqli_query($conn, $query);

if (!$result_order || mysqli_num_rows($result_order) == 0) {
    die("Error: Order ID tidak valid atau tidak ditemukan.");
}

$order = mysqli_fetch_assoc($result_order);

// Query untuk mengambil item pesanan
$query_items = "SELECT * FROM produksi WHERE id_order = '$order_id'";
$order_items = mysqli_query($conn, $query_items);

// Membuat kelas PDF
class PDF extends FPDF
{
    // Header
    function Header()
    {
        // Judul halaman
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Struk Pesanan', 0, 1, 'C');
        $this->Ln(5);
    }

    // Footer
    function Footer()
    {
        // Nomor halaman
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Halaman ' . $this->PageNo(), 0, 0, 'C');
    }

    // Detail Pesanan
    function OrderDetails($order, $order_items)
    {
        $this->SetFont('Arial', '', 12);
        $this->Cell(30, 10, 'Order ID:', 0, 0);
        $this->Cell(50, 10, $order['id_order'], 0, 1);

        $this->Cell(30, 10, 'Nama:', 0, 0);
        $this->Cell(50, 10, $order['nama'], 0, 1);

        $this->Cell(30, 10, 'Alamat:', 0, 0);
        $this->Cell(50, 10, $order['alamat'], 0, 1);

        $this->Ln(10);

        $this->Cell(10, 10, 'No', 1);
        $this->Cell(70, 10, 'Nama Produk', 1);
        $this->Cell(30, 10, 'Harga', 1);
        $this->Cell(20, 10, 'Qty', 1);
        $this->Cell(30, 10, 'Sub Total', 1);
        $this->Ln();

        $no = 1;
        $total = 0;
        while ($item = mysqli_fetch_assoc($order_items)) {
            $this->Cell(10, 10, $no, 1);
            $this->Cell(70, 10, $item['nama_produk'], 1); // Sesuaikan dengan field yang sesuai
            $this->Cell(30, 10, 'Rp.' . number_format($item['harga']), 1);
            $this->Cell(20, 10, $item['qty'], 1);
            $this->Cell(30, 10, 'Rp.' . number_format($item['harga'] * $item['qty']), 1);
            $this->Ln();

            $total += $item['harga'] * $item['qty'];
            $no++;
        }

        $this->Cell(130, 10, 'Grand Total', 1);
        $this->Cell(30, 10, 'Rp.' . number_format($total), 1);
    }
}

// Membuat objek PDF
$pdf = new PDF();
$pdf->AddPage();
$pdf->OrderDetails($order, $order_items);

// Menampilkan output PDF
$pdf->Output('I', 'Struk_Pesanan.pdf');
?>
